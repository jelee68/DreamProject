package com.triple.dreamlib.dto;

public class UserDto {

}
