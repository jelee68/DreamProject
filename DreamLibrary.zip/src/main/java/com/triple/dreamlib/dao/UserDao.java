package com.triple.dreamlib.dao;

public class UserDao {

}
