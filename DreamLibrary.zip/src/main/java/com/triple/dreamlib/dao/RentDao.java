package com.triple.dreamlib.dao;

public interface RentDao {

}
